# Changelog

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [1.0.0] - 2021-10-01
### Changes
- Created
- Added function `get_test_data_path(module: str, subpath: str = "") -> str`
- Added function `wait_stage_loading(usd_context=omni.usd.get_context())`
- Added function `open_stage(path: str, usd_context=omni.usd.get_context())`
- Added function `select_prims(paths, usd_context=omni.usd.get_context())`
- Added function `set_content_browser_grid_view(grid_view_enabled: bool)`
- Added function `get_content_browser_path_item(path: str)`
- Added function `get_prims(stage, exclude_list=[])`
- Added function `wait_for_window(window_name: str)`
- Added function `handle_assign_material_dialog(index)`
- Added function `handle_create_material_dialog(mdl_path: str, mtl_name: str)`
- Added function `handle_add_material_dialog(mdl_path: str, mtl_name: str)`
- Added function `delete_prim_path_children(prim_path: str)`
- Added function `build_sdf_asset_frame_dictonary()`
- Added function `get_prim_viewport_position(prim_path: str)`
- Added function `push_window_height(cls, window_name, new_height=None)`
- Added function `pop_window_height(cls, window_name)`
- Added function `handle_multiple_descendents_dialog(stage, prim_path: str, target_prim: str)`
